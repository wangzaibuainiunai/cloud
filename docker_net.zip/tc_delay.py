import yaml
import os
import re
import sys
router={}
host={}
with open('data.txt') as f:
    for line in f:
        list.extend([int(i) for i in line.split()])
delay=list.pop()
range=delay/10
yamlpath=os.path.join("/home/seed/Desktop/cyber_range/docker_net/output/docker-compose.yml")
file = open(yamlpath, 'r', encoding='utf-8')
filer = file.read()
content=yaml.load(filer,Loader=yaml.SafeLoader)
content2=content['services']
for key in content2.keys():
    if re.search(r'router',key) is not None:
        trans=content2[key]
        router[key]=trans['container_name']
for key in content2.keys():
    if re.search(r'host',key) is not None:
        trans=content2[key]
        host[key]=trans['container_name']
script= open('script.sh',"w")
for key in router.keys():
    script.write("docker exec "+router[key]+" tc qdisc del dev net0 root \n")
    script.write("docker exec "+router[key]+" tc qdisc add dev net0 root netem delay "+delay+" "+"range " +"distribution normal \n")
for key in host.keys():
    #script.write("docker exec "+host[key]+" tcpdump -w ./tmp.pcap & \n")
    script.write("docker exec "+host[key]+" tcpdump icmp -Xvnn > ./tmp.log & \n")

script.close()
print(host)
