#!/usr/bin/bash
cd /home/seed/Desktop/cyber_range/docker_net/output
docker-compose down 
cd /home/seed/Desktop/cyber_range/docker_net
rm -rf output/
python3 main.py
cd output/
docker-compose build
docker-compose up -d
cd /home/seed/Desktop/cyber_range/docker_net
python3 tc_delay.py
chmod +x script.sh
./script.sh
