docker exec as120r-router0-10.120.0.254 tc qdisc del dev net0 root 
docker exec as120r-router0-10.120.0.254 tc qdisc add dev net0 root netem delay 100ms 20ms distribution normal 
docker exec as121r-router0-10.121.0.254 tc qdisc del dev net0 root 
docker exec as121r-router0-10.121.0.254 tc qdisc add dev net0 root netem delay 100ms 20ms distribution normal 
docker exec as120h-host_0-10.120.0.71 tcpdump icmp -Xvnn > ./tmp.log & 
docker exec as120h-host_1-10.120.0.72 tcpdump icmp -Xvnn > ./tmp.log & 
docker exec as121h-host_0-10.121.0.71 tcpdump icmp -Xvnn > ./tmp.log & 
docker exec as121h-host_1-10.121.0.72 tcpdump icmp -Xvnn > ./tmp.log & 
docker exec as121h-host_2-10.121.0.73 tcpdump icmp -Xvnn > ./tmp.log & 
docker exec as121h-host_3-10.121.0.74 tcpdump icmp -Xvnn > ./tmp.log & 
